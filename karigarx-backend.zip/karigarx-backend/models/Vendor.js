// ─── models/Vendor.js ────────────────────────────────────────────────────────
const mongoose = require('mongoose');

const VendorSchema = new mongoose.Schema({
  name:        { type: String, required: true },
  email:       { type: String, required: true, unique: true },
  phone:       { type: String },
  city:        { type: String },
  specialty:   [String],          // e.g. ['chairs','sofas']
  rating:      { type: Number, default: 4.5 },
  totalOrders: { type: Number, default: 0 },
  isOnline:    { type: Boolean, default: false },
  socketId:    { type: String, default: null },  // live socket id
  createdAt:   { type: Date, default: Date.now },
});

module.exports = mongoose.model('Vendor', VendorSchema);
