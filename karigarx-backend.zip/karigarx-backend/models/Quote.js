// ─── models/Quote.js ─────────────────────────────────────────────────────────
const mongoose = require('mongoose');

const QuoteSchema = new mongoose.Schema({
  orderId:    { type: mongoose.Schema.Types.ObjectId, ref: 'Order', required: true },
  vendorId:   { type: mongoose.Schema.Types.ObjectId, ref: 'Vendor', required: true },
  vendorName: { type: String },

  price:       { type: Number, required: true },
  note:        { type: String, default: '' },       // vendor message to user
  deliveryDays:{ type: Number, default: 7 },

  status: {
    type: String,
    enum: ['pending', 'submitted', 'accepted', 'rejected'],
    default: 'pending',
  },

  submittedAt: { type: Date, default: null },
  createdAt:   { type: Date, default: Date.now },
});

module.exports = mongoose.model('Quote', QuoteSchema);
