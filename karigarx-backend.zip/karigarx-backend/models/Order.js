// ─── models/Order.js ─────────────────────────────────────────────────────────
const mongoose = require('mongoose');

const OrderSchema = new mongoose.Schema({
  // Who placed it
  userId:   { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  userName: { type: String },
  userPhone:{ type: String },
  userCity: { type: String },

  // What they want
  config: {
    category:     String,
    chairType:    String,
    designName:   String,
    material:     String,
    finish:       String,
    frameColor:   String,
    cushionColor: String,
    dimensions: {
      width:  Number,
      depth:  Number,
      height: Number,
      seatHeight: Number,
    },
    accessories:  [String],
    addons:       [String],
    fabricMode:   String,
  },

  // Frontend calculated estimate
  estimatedPrice: { type: Number, required: true },

  // Which vendors were pinged
  targetVendors: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Vendor' }],

  // Order lifecycle
  status: {
    type: String,
    enum: ['open', 'quoted', 'accepted', 'expired', 'cancelled'],
    default: 'open',
  },

  // Accepted quote (set when user picks one)
  acceptedQuoteId: { type: mongoose.Schema.Types.ObjectId, ref: 'Quote', default: null },

  expiresAt: { type: Date },   // set to now + QUOTE_TIMEOUT_MS
  createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model('Order', OrderSchema);
