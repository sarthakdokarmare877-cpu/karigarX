// ─── server.js ───────────────────────────────────────────────────────────────
require('dotenv').config();

const express    = require('express');
const http       = require('http');
const { Server } = require('socket.io');
const mongoose   = require('mongoose');
const cors       = require('cors');

const orderRoutes  = require('./routes/orders');
const vendorRoutes = require('./routes/vendors');
const setupSocket  = require('./socket/index');

const app    = express();
const server = http.createServer(app);

// ── Socket.IO setup ──────────────────────────────────────────────────────────
const io = new Server(server, {
  cors: {
    origin: '*',      // In production: restrict to your frontend domain
    methods: ['GET', 'POST'],
  },
});

// Make io available to routes via req.app.get('io')
app.set('io', io);

// ── Middleware ────────────────────────────────────────────────────────────────
app.use(cors());
app.use(express.json());

// ── Routes ────────────────────────────────────────────────────────────────────
app.use('/api/orders',  orderRoutes);
app.use('/api/vendors', vendorRoutes);

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', ts: new Date() });
});

// ── Socket handlers ───────────────────────────────────────────────────────────
setupSocket(io);

// ── MongoDB + start ───────────────────────────────────────────────────────────
mongoose.connect(process.env.MONGO_URI)
  .then(() => {
    console.log('✅ MongoDB connected');
    const PORT = process.env.PORT || 4000;
    server.listen(PORT, () => {
      console.log(`🚀 Server running on http://localhost:${PORT}`);
    });
  })
  .catch(err => {
    console.error('❌ MongoDB connection error:', err.message);
    process.exit(1);
  });
