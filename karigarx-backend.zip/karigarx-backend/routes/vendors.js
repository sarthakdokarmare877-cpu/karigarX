// ─── routes/vendors.js ───────────────────────────────────────────────────────
const express = require('express');
const router  = express.Router();
const Vendor  = require('../models/Vendor');
const Quote   = require('../models/Quote');
const Order   = require('../models/Order');

// ── GET /api/vendors ──────────────────────────────────────────────────────────
// List all vendors (admin / demo)
router.get('/', async (req, res) => {
  try {
    const vendors = await Vendor.find({}).select('-socketId');
    res.json({ vendors });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/vendors ─────────────────────────────────────────────────────────
// Register a new vendor (demo — no auth)
router.post('/', async (req, res) => {
  try {
    const { name, email, phone, city, specialty } = req.body;
    if (!name || !email) return res.status(400).json({ error: 'name and email required' });
    const vendor = await Vendor.create({ name, email, phone, city, specialty });
    res.status(201).json({ success: true, vendor });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── GET /api/vendors/:vendorId/orders ─────────────────────────────────────────
// Vendor's dashboard: see all quote requests sent to them
router.get('/:vendorId/orders', async (req, res) => {
  try {
    const { status } = req.query;   // ?status=pending

    const query = { vendorId: req.params.vendorId };
    if (status) query.status = status;

    const quotes = await Quote.find(query)
      .populate('orderId')
      .sort({ createdAt: -1 });

    const result = quotes.map(q => ({
      quoteId:        q._id,
      status:         q.status,
      price:          q.price,
      note:           q.note,
      deliveryDays:   q.deliveryDays,
      submittedAt:    q.submittedAt,
      order: q.orderId ? {
        orderId:        q.orderId._id,
        userName:       q.orderId.userName,
        userCity:       q.orderId.userCity,
        config:         q.orderId.config,
        estimatedPrice: q.orderId.estimatedPrice,
        status:         q.orderId.status,
        expiresAt:      q.orderId.expiresAt,
        createdAt:      q.orderId.createdAt,
      } : null,
    }));

    res.json({ quotes: result });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/vendors/:vendorId/quote ─────────────────────────────────────────
// Vendor submits (or updates) their price for an order
router.post('/:vendorId/quote', async (req, res) => {
  try {
    const { orderId, price, note, deliveryDays } = req.body;
    if (!orderId || !price) return res.status(400).json({ error: 'orderId and price required' });

    // Find the pending quote for this vendor + order
    const quote = await Quote.findOne({ orderId, vendorId: req.params.vendorId });
    if (!quote) return res.status(404).json({ error: 'Quote not found' });

    const order = await Order.findById(orderId);
    if (!order) return res.status(404).json({ error: 'Order not found' });
    if (order.status !== 'open') {
      return res.status(400).json({ error: 'Order is no longer open' });
    }
    if (new Date() > new Date(order.expiresAt)) {
      return res.status(400).json({ error: 'Quote window has expired' });
    }

    // Update quote
    quote.price        = parseFloat(price);
    quote.note         = note || '';
    quote.deliveryDays = deliveryDays || 7;
    quote.status       = 'submitted';
    quote.submittedAt  = new Date();
    await quote.save();

    // Mark order as 'quoted' if still open
    if (order.status === 'open') {
      order.status = 'quoted';
      await order.save();
    }

    // ── REAL-TIME: emit to user's order room ──────────────────────────────────
    const io = req.app.get('io');

    // Get all quotes to calculate best price
    const allQuotes = await Quote.find({ orderId }).sort({ price: 1 });
    const submitted  = allQuotes.filter(q => q.status === 'submitted');
    const bestPrice  = submitted.length ? submitted[0].price : null;

    const quotePayload = {
      quoteId:      quote._id,
      vendorId:     req.params.vendorId,
      vendorName:   quote.vendorName,
      price:        quote.price,
      note:         quote.note,
      deliveryDays: quote.deliveryDays,
      isBest:       quote.price === bestPrice,
      submittedAt:  quote.submittedAt,
    };

    // Push to user watching this order
    io.to(`order_${orderId}`).emit('quote_received', quotePayload);

    // If there was a previous best, tell user which changed
    if (submitted.length > 1) {
      io.to(`order_${orderId}`).emit('best_price_updated', {
        bestPrice,
        bestVendorName: submitted[0].vendorName,
      });
    }

    res.json({ success: true, quote: quotePayload });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/vendors/:vendorId/reject ────────────────────────────────────────
// Vendor rejects an order (won't quote)
router.post('/:vendorId/reject', async (req, res) => {
  try {
    const { orderId } = req.body;
    const quote = await Quote.findOne({ orderId, vendorId: req.params.vendorId });
    if (!quote) return res.status(404).json({ error: 'Quote not found' });

    quote.status = 'rejected';
    await quote.save();

    // Notify user that this vendor passed
    const io = req.app.get('io');
    io.to(`order_${orderId}`).emit('vendor_rejected', {
      vendorId:   req.params.vendorId,
      vendorName: quote.vendorName,
    });

    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
