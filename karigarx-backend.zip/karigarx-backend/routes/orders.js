// ─── routes/orders.js ────────────────────────────────────────────────────────
const express  = require('express');
const router   = express.Router();
const Order    = require('../models/Order');
const Quote    = require('../models/Quote');
const Vendor   = require('../models/Vendor');

// ── POST /api/orders ──────────────────────────────────────────────────────────
// User places a quote request. Creates Order + pending Quote per vendor.
// Also emits 'new_order' to each vendor via socket.
router.post('/', async (req, res) => {
  try {
    const {
      userId, userName, userPhone, userCity,
      config, estimatedPrice,
    } = req.body;

    if (!userId || !config || !estimatedPrice) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    // Find online vendors (or all vendors if none online — demo mode)
    let vendors = await Vendor.find({ isOnline: true });
    if (vendors.length === 0) vendors = await Vendor.find({}).limit(5);
    if (vendors.length === 0) {
      return res.status(503).json({ error: 'No vendors available right now' });
    }

    const timeoutMs = parseInt(process.env.QUOTE_TIMEOUT_MS) || 120000;

    // Create the order
    const order = await Order.create({
      userId,
      userName,
      userPhone,
      userCity,
      config,
      estimatedPrice,
      targetVendors: vendors.map(v => v._id),
      status: 'open',
      expiresAt: new Date(Date.now() + timeoutMs),
    });

    // Create one pending Quote per vendor
    const quotes = await Quote.insertMany(
      vendors.map(v => ({
        orderId:    order._id,
        vendorId:   v._id,
        vendorName: v.name,
        price:      0,
        status:     'pending',
      }))
    );

    // Emit to each vendor's socket room (if connected)
    const io = req.app.get('io');
    const orderPayload = {
      orderId:        order._id,
      userName:       userName || 'Customer',
      userCity:       userCity || '',
      config,
      estimatedPrice,
      expiresAt:      order.expiresAt,
    };

    vendors.forEach(v => {
      io.to(`vendor_${v._id}`).emit('new_order', orderPayload);
    });

    // Auto-expire order after timeout
    setTimeout(async () => {
      const o = await Order.findById(order._id);
      if (o && o.status === 'open') {
        o.status = 'expired';
        await o.save();
        io.to(`order_${order._id}`).emit('order_expired', { orderId: order._id });
      }
    }, timeoutMs);

    res.status(201).json({
      success:  true,
      orderId:  order._id,
      vendors:  vendors.map(v => ({
        vendorId:   v._id,
        vendorName: v.name,
        status:     'waiting',
      })),
    });

  } catch (err) {
    console.error('POST /orders error:', err);
    res.status(500).json({ error: err.message });
  }
});

// ── GET /api/orders/:orderId/quotes ──────────────────────────────────────────
// User polls OR loads current quote state for an order
router.get('/:orderId/quotes', async (req, res) => {
  try {
    const quotes = await Quote.find({ orderId: req.params.orderId })
      .sort({ price: 1 });   // sorted ascending so index 0 = cheapest

    if (!quotes.length) return res.status(404).json({ error: 'No quotes found' });

    // Tag best price
    const submitted = quotes.filter(q => q.status === 'submitted');
    let bestPrice = submitted.length
      ? Math.min(...submitted.map(q => q.price))
      : null;

    const result = quotes.map(q => ({
      quoteId:      q._id,
      vendorId:     q.vendorId,
      vendorName:   q.vendorName,
      price:        q.price,
      note:         q.note,
      deliveryDays: q.deliveryDays,
      status:       q.status,
      isBest:       q.status === 'submitted' && q.price === bestPrice,
      submittedAt:  q.submittedAt,
    }));

    res.json({ quotes: result });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/orders/:orderId/accept ─────────────────────────────────────────
// User accepts a specific vendor quote
router.post('/:orderId/accept', async (req, res) => {
  try {
    const { quoteId } = req.body;
    if (!quoteId) return res.status(400).json({ error: 'quoteId required' });

    const quote = await Quote.findById(quoteId);
    if (!quote) return res.status(404).json({ error: 'Quote not found' });

    const order = await Order.findById(req.params.orderId);
    if (!order) return res.status(404).json({ error: 'Order not found' });

    // Update order
    order.status = 'accepted';
    order.acceptedQuoteId = quoteId;
    await order.save();

    // Update winning quote
    quote.status = 'accepted';
    await quote.save();

    // Reject all other quotes for this order
    await Quote.updateMany(
      { orderId: order._id, _id: { $ne: quoteId } },
      { status: 'rejected' }
    );

    // Notify vendor
    const io = req.app.get('io');
    io.to(`vendor_${quote.vendorId}`).emit('quote_accepted', {
      orderId:   order._id,
      quoteId:   quote._id,
      userName:  order.userName,
      price:     quote.price,
    });

    res.json({ success: true, message: 'Quote accepted!' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
