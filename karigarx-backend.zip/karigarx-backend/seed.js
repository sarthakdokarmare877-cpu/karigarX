// ─── seed.js ─────────────────────────────────────────────────────────────────
// Run: node seed.js
// Creates 5 test vendors in your MongoDB

require('dotenv').config();
const mongoose = require('mongoose');
const Vendor   = require('./models/Vendor');

const VENDORS = [
  { name: 'Ratan Furniture Works',  email: 'ratan@test.com',  city: 'Jodhpur',  specialty: ['chairs', 'sofas'],  rating: 4.8 },
  { name: 'Mumbai Craft Studio',    email: 'mumbai@test.com', city: 'Mumbai',   specialty: ['chairs', 'tables'], rating: 4.7 },
  { name: 'Delhi Wood Masters',     email: 'delhi@test.com',  city: 'Delhi',    specialty: ['chairs', 'beds'],   rating: 4.6 },
  { name: 'Pune Artisan Collective',email: 'pune@test.com',   city: 'Pune',     specialty: ['chairs'],           rating: 4.9 },
  { name: 'Bangalore Makers Hub',   email: 'blr@test.com',   city: 'Bangalore',specialty: ['chairs', 'desks'],  rating: 4.5 },
];

async function seed() {
  await mongoose.connect(process.env.MONGO_URI);
  await Vendor.deleteMany({});
  const vendors = await Vendor.insertMany(VENDORS);
  console.log('✅ Seeded vendors:');
  vendors.forEach(v => console.log(`  ${v._id}  ${v.name}`));
  console.log('\nCopy these IDs into vendor dashboard for testing.');
  await mongoose.disconnect();
}

seed().catch(console.error);
