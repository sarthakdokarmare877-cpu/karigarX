// ─── socket/index.js ─────────────────────────────────────────────────────────
// All real-time logic lives here.
// Rooms used:
//   order_{orderId}    → user watching their quote board
//   vendor_{vendorId}  → vendor receiving new orders

const Vendor = require('../models/Vendor');

module.exports = function setupSocket(io) {

  io.on('connection', (socket) => {
    console.log('🔌 Socket connected:', socket.id);

    // ── USER joins their order room ──────────────────────────────────────────
    // Client call: socket.emit('join_order', { orderId })
    socket.on('join_order', ({ orderId }) => {
      if (!orderId) return;
      socket.join(`order_${orderId}`);
      console.log(`👤 User joined order room: order_${orderId}`);
    });

    // ── VENDOR comes online ──────────────────────────────────────────────────
    // Client call: socket.emit('vendor_online', { vendorId })
    socket.on('vendor_online', async ({ vendorId }) => {
      if (!vendorId) return;
      socket.join(`vendor_${vendorId}`);

      // Mark vendor as online + store their socket id
      await Vendor.findByIdAndUpdate(vendorId, {
        isOnline: true,
        socketId: socket.id,
      });

      console.log(`🏭 Vendor online: vendor_${vendorId} (${socket.id})`);

      // Acknowledge vendor
      socket.emit('vendor_ready', { vendorId, message: 'You are now online and receiving orders.' });
    });

    // ── VENDOR goes offline / disconnects ────────────────────────────────────
    socket.on('disconnect', async () => {
      console.log('❌ Socket disconnected:', socket.id);

      // Find vendor by this socket id and mark offline
      await Vendor.findOneAndUpdate(
        { socketId: socket.id },
        { isOnline: false, socketId: null }
      );
    });

    // ── PING (health check from client) ──────────────────────────────────────
    socket.on('ping_server', () => {
      socket.emit('pong_server', { ts: Date.now() });
    });
  });

};
